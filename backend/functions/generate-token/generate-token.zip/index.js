exports.handler = async (event) => { return { statusCode: 200, body: JSON.stringify("Generate Token Function") }; };
